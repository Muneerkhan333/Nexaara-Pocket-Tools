import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/ads_service.dart';
import '../../services/database_service.dart';
import '../../utils/constants.dart';
import '../../utils/helpers.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _isDarkMode = false;
  bool _showAds = true;
  bool _isPremium = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isDarkMode = prefs.getBool('dark_mode') ?? false;
      _showAds = prefs.getBool('show_ads') ?? true;
      _isPremium = context.read<AdsService>().isPremium;
    });
  }

  Future<void> _saveSetting(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        children: [
          // App Info
          _buildSectionHeader('App Info'),
          ListTile(
            leading: const Icon(Icons.info),
            title: const Text('Version'),
            subtitle: Text(AppConstants.appVersion),
            trailing: GestureDetector(
              onLongPress: () => _showDebugMenu(),
              child: const Text('Debug'),
            ),
          ),

          // Appearance
          _buildSectionHeader('Appearance'),
          SwitchListTile(
            secondary: const Icon(Icons.dark_mode),
            title: const Text('Dark Mode'),
            subtitle: const Text('Toggle between light and dark themes'),
            value: _isDarkMode,
            onChanged: (value) {
              setState(() => _isDarkMode = value);
              _saveSetting('dark_mode', value);
              // TODO: Implement theme switching
            },
          ),

          // Ads & Premium
          _buildSectionHeader('Ads & Premium'),
          SwitchListTile(
            secondary: const Icon(Icons.ad_units),
            title: const Text('Show Ads'),
            subtitle: const Text('Display banner and interstitial ads'),
            value: _showAds && !_isPremium,
            onChanged: _isPremium ? null : (value) {
              setState(() => _showAds = value);
              _saveSetting('show_ads', value);
            },
          ),
          ListTile(
            leading: Icon(
              _isPremium ? Icons.star : Icons.star_border,
              color: _isPremium ? Colors.amber : null,
            ),
            title: Text(_isPremium ? 'Premium Active' : 'Upgrade to Premium'),
            subtitle: const Text('Remove ads and unlock cloud backup'),
            trailing: _isPremium
                ? const Icon(Icons.check_circle, color: Colors.green)
                : const Icon(Icons.arrow_forward_ios),
            onTap: _isPremium ? null : () => _showPremiumDialog(),
          ),

          // Data Management
          _buildSectionHeader('Data Management'),
          ListTile(
            leading: const Icon(Icons.clear_all),
            title: const Text('Clear Cache'),
            subtitle: const Text('Clear temporary data and cache'),
            onTap: () => _clearCache(),
          ),
          ListTile(
            leading: const Icon(Icons.delete_sweep),
            title: const Text('Clear QR History'),
            subtitle: const Text('Delete all QR scan history'),
            onTap: () => _clearQRHistory(),
          ),

          // Support
          _buildSectionHeader('Support'),
          ListTile(
            leading: const Icon(Icons.privacy_tip),
            title: const Text('Privacy Policy'),
            subtitle: const Text('Read our privacy policy'),
            onTap: () => Helpers.launchURL(AppConstants.privacyPolicyUrl),
          ),
          ListTile(
            leading: const Icon(Icons.contact_mail),
            title: const Text('Contact Support'),
            subtitle: const Text('Get help or send feedback'),
            onTap: () => Helpers.launchEmail(AppConstants.supportEmail),
          ),

          // Language
          _buildSectionHeader('Language'),
          ListTile(
            leading: const Icon(Icons.language),
            title: const Text('Language'),
            subtitle: const Text('English / Urdu'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () => _showLanguageDialog(),
          ),

          // About
          _buildSectionHeader('About'),
          ListTile(
            leading: const Icon(Icons.business),
            title: const Text('About Nexaara'),
            subtitle: const Text('Learn more about our app'),
            onTap: () => _showAboutDialog(),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Theme.of(context).primaryColor,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  void _showPremiumDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Upgrade to Premium'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.star, size: 48, color: Colors.amber),
            SizedBox(height: 16),
            Text(
              'Premium Features:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text('• Ad-free experience'),
            Text('• Google Sheets backup & sync'),
            Text('• Priority support'),
            SizedBox(height: 16),
            Text(
              'Mock Subscription - In a real app, this would integrate with payment providers.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              context.read<AdsService>().upgradeToPremium();
              setState(() => _isPremium = true);
              Navigator.of(context).pop();
              Helpers.showSnackBar(context, 'Welcome to Premium!');
            },
            child: const Text('Upgrade Now'),
          ),
        ],
      ),
    );
  }

  void _clearCache() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Cache'),
        content: const Text('This will clear temporary data. Continue?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              // TODO: Implement cache clearing
              Navigator.of(context).pop();
              Helpers.showSnackBar(context, 'Cache cleared');
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  void _clearQRHistory() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear QR History'),
        content: const Text('This will permanently delete all QR scan history. Continue?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              context.read<DatabaseService>().clearAllQRScans();
              Navigator.of(context).pop();
              Helpers.showSnackBar(context, 'QR history cleared');
            },
            child: const Text('Clear All'),
          ),
        ],
      ),
    );
  }

  void _showLanguageDialog() {
    showDialog(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('Select Language'),
        children: [
          SimpleDialogOption(
            onPressed: () {
              // TODO: Implement language switching
              Navigator.of(context).pop();
              Helpers.showSnackBar(context, 'Language switched to English');
            },
            child: const Text('English'),
          ),
          SimpleDialogOption(
            onPressed: () {
              // TODO: Implement language switching
              Navigator.of(context).pop();
              Helpers.showSnackBar(context, 'Language switched to Urdu');
            },
            child: const Text('Urdu (اردو)'),
          ),
        ],
      ),
    );
  }

  void _showAboutDialog() {
    showAboutDialog(
      context: context,
      applicationName: AppConstants.appName,
      applicationVersion: AppConstants.appVersion,
      applicationLegalese: '© 2024 Nexaara Pocket Tools',
      children: [
        const SizedBox(height: 16),
        const Text(AppConstants.appSlogan),
        const SizedBox(height: 8),
        const Text(
          'A comprehensive offline toolkit featuring QR scanning, note management, and currency conversion with premium UI/UX design.',
        ),
      ],
    );
  }

  void _showDebugMenu() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Debug Menu'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('Reset All Settings'),
              onTap: () {
                // TODO: Implement reset
                Navigator.of(context).pop();
                Helpers.showSnackBar(context, 'Settings reset');
              },
            ),
            ListTile(
              title: const Text('Export Debug Info'),
              onTap: () {
                // TODO: Implement debug export
                Navigator.of(context).pop();
                Helpers.showSnackBar(context, 'Debug info exported');
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}
