# Nexaara Pocket Tools

A comprehensive, offline-first Flutter app featuring QR code scanning, note management, and currency conversion with premium UI/UX design.

## Features

### 🔍 QR Scanner
- Real-time QR code scanning using device camera
- Automatic data type detection (URL, text, contact, etc.)
- Scan history with timestamp and type
- Copy/share scanned data
- Export history to CSV
- Optional Google Sheets backup

### 📝 Notes Manager
- Full CRUD operations for notes
- Color-coded notes with tagging
- Search functionality
- Pin important notes
- Export to CSV or text file
- Google Sheets backup (premium feature)

### 💱 Currency Converter
- Real-time exchange rates via free API
- Offline mode with preloaded rates
- Favorite currency pairs
- Quick convert buttons
- Manual rate editing

### 🎨 Premium UI/UX
- Modern glassmorphism design
- Smooth animations and transitions
- Dark/Light mode support
- Multi-language (English/Urdu)
- Onboarding experience

### 📱 Monetization
- Google AdMob integration (banner + interstitial)
- Mock premium subscription system
- Ad-free experience for premium users

## Screenshots

*(Add screenshots here)*

## Installation

1. **Prerequisites:**
   - Flutter SDK (latest stable)
   - Android Studio or VS Code
   - Android/iOS device or emulator

2. **Clone the repository:**
   ```bash
   git clone https://github.com/yourusername/nexaara-pocket-tools.git
   cd nexaara-pocket-tools
   ```

3. **Install dependencies:**
   ```bash
   flutter pub get
   ```

4. **Run the app:**
   ```bash
   flutter run
   ```

## Configuration

### AdMob Setup
1. Create AdMob account and get App ID
2. Create banner and interstitial ad units
3. Replace test IDs in `lib/src/services/ads_service.dart`:
   ```dart
   static const String bannerAdUnitId = 'your_banner_ad_unit_id';
   static const String interstitialAdUnitId = 'your_interstitial_ad_unit_id';
   ```

### Google Sheets Backup (Optional)
1. Create a new Google Apps Script project
2. Copy the code from `apps-script.gs` to your script
3. Deploy as web app and get the URL
4. Update `lib/src/services/google_sheets_service.dart`:
   ```dart
   static const String _scriptUrl = 'your_deployed_script_url';
   static const String _secretToken = 'your_secure_token';
   ```

### Subscription Setup
For production, integrate with payment providers like:
- Google Play Billing (Android)
- App Store Connect (iOS)
- Stripe (cross-platform)

## Project Structure

```
lib/
├── main.dart                 # App entry point
├── src/
│   ├── models/               # Data models
│   │   ├── note.dart
│   │   ├── qr_scan.dart
│   │   └── currency.dart
│   ├── services/             # Business logic
│   │   ├── database_service.dart
│   │   ├── api_service.dart
│   │   ├── ads_service.dart
│   │   └── google_sheets_service.dart
│   ├── utils/                # Utilities
│   │   ├── constants.dart
│   │   └── helpers.dart
│   └── ui/
│       ├── themes/
│       │   └── app_theme.dart
│       ├── screens/          # App screens
│       │   ├── home_screen.dart
│       │   ├── qr_scanner_screen.dart
│       │   ├── notes_screen.dart
│       │   ├── currency_converter_screen.dart
│       │   ├── settings_screen.dart
│       │   └── onboarding_screen.dart
│       └── widgets/          # Reusable widgets
│           ├── multi_action_fab.dart
│           ├── glassmorphism_card.dart
│           └── shimmer_loader.dart
assets/
├── fonts/                    # Custom fonts
├── images/                   # App images
└── lottie/                   # Animations
```

## Dependencies

- **State Management:** Provider
- **Database:** Hive (local storage)
- **Ads:** Google Mobile Ads
- **QR Scanning:** mobile_scanner
- **Animations:** Lottie, flutter_animate
- **UI:** Glassmorphism effects, custom themes

## Testing

Run tests:
```bash
flutter test
```

## Building for Production

### Android APK:
```bash
flutter build apk --release
```

### iOS (on macOS):
```bash
flutter build ios --release
```

### Play Store Deployment:
1. Generate signed APK/AAB
2. Create Play Store listing
3. Upload and publish

## Privacy Policy

See `privacy_policy.md` for the complete privacy policy.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@nexaara.com or create an issue on GitHub.

---

**Made with ❤️ by Nexaara Team**
