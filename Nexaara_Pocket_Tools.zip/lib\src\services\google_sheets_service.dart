import 'dart:convert';
import 'package:http/http.dart' as http;

class GoogleSheetsService {
  static const String _scriptUrl = 'https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec'; // Replace with actual Apps Script URL
  static const String _secretToken = 'your_secret_token_here'; // Secure token for authentication

  // Backup notes to Google Sheets
  static Future<bool> backupNotes(List<Map<String, dynamic>> notes) async {
    try {
      final response = await http.post(
        Uri.parse(_scriptUrl),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'action': 'backup_notes',
          'token': _secretToken,
          'data': notes,
        }),
      );

      return response.statusCode == 200 && json.decode(response.body)['success'] == true;
    } catch (e) {
      return false;
    }
  }

  // Restore notes from Google Sheets
  static Future<List<Map<String, dynamic>>> restoreNotes() async {
    try {
      final response = await http.post(
        Uri.parse(_scriptUrl),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'action': 'restore_notes',
          'token': _secretToken,
        }),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return List<Map<String, dynamic>>.from(data['notes'] ?? []);
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // Export QR scans to Google Sheets
  static Future<bool> exportQRScans(List<Map<String, dynamic>> scans) async {
    try {
      final response = await http.post(
        Uri.parse(_scriptUrl),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'action': 'export_qr_scans',
          'token': _secretToken,
          'data': scans,
        }),
      );

      return response.statusCode == 200 && json.decode(response.body)['success'] == true;
    } catch (e) {
      return false;
    }
  }
}
