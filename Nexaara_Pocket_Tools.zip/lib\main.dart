import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';
import 'src/models/note.dart';
import 'src/models/qr_scan.dart';
import 'src/services/database_service.dart';
import 'src/services/ads_service.dart';
import 'src/ui/themes/app_theme.dart';
import 'src/ui/screens/onboarding_screen.dart';
import 'src/ui/screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Hive for local storage
  await Hive.initFlutter();
  Hive.registerAdapter(NoteAdapter());
  Hive.registerAdapter(QRScanAdapter());
  await Hive.openBox<Note>('notes');
  await Hive.openBox<QRScan>('qr_scans');

  // Initialize AdMob
  await AdsService.init();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => DatabaseService()),
        ChangeNotifierProvider(create: (_) => AdsService()),
      ],
      child: MaterialApp(
        title: 'Nexaara Pocket Tools',
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: const [
          Locale('en', ''), // English
          Locale('ur', ''), // Urdu
        ],
        home: const AppWrapper(),
      ),
    );
  }
}

class AppWrapper extends StatefulWidget {
  const AppWrapper({super.key});

  @override
  State<AppWrapper> createState() => _AppWrapperState();
}

class _AppWrapperState extends State<AppWrapper> {
  bool _showOnboarding = true;

  @override
  void initState() {
    super.initState();
    _checkFirstLaunch();
  }

  void _checkFirstLaunch() async {
    // TODO: Check if user has seen onboarding before
    // For now, always show onboarding
    await Future.delayed(const Duration(seconds: 2));
    setState(() {
      _showOnboarding = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return _showOnboarding ? const OnboardingScreen() : const HomeScreen();
  }
}
