import 'package:hive/hive.dart';

part 'note.g.dart';

@HiveType(typeId: 0)
class Note extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String title;

  @HiveField(2)
  String content;

  @HiveField(3)
  DateTime createdAt;

  @HiveField(4)
  DateTime updatedAt;

  @HiveField(5)
  int colorIndex;

  @HiveField(6)
  bool isPinned;

  Note({
    required this.id,
    required this.title,
    required this.content,
    required this.createdAt,
    required this.updatedAt,
    this.colorIndex = 0,
    this.isPinned = false,
  });

  // Colors for notes
  static const List<int> colors = [
    0xFF23395B, // Deep Indigo
    0xFF0FB9B1, // Electric Cyan
    0xFFF7C948, // Soft Gold
    0xFF6C757D, // Gray
  ];
}
