import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import '../screens/qr_scanner_screen.dart';
import '../screens/notes_screen.dart';

class MultiActionFAB extends StatelessWidget {
  const MultiActionFAB({super.key});

  @override
  Widget build(BuildContext context) {
    return SpeedDial(
      icon: Icons.add,
      activeIcon: Icons.close,
      backgroundColor: Theme.of(context).floatingActionButtonTheme.backgroundColor,
      foregroundColor: Theme.of(context).floatingActionButtonTheme.foregroundColor,
      children: [
        SpeedDialChild(
          child: const Icon(Icons.qr_code_scanner),
          backgroundColor: const Color(0xFF0FB9B1),
          foregroundColor: Colors.white,
          label: 'Scan QR',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const QRScannerScreen()),
          ),
        ),
        SpeedDialChild(
          child: const Icon(Icons.note_add),
          backgroundColor: const Color(0xFFF7C948),
          foregroundColor: Colors.white,
          label: 'New Note',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const NotesScreen()),
          ),
        ),
      ],
    );
  }
}
