import 'package:flutter_test/flutter_test.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:nexaara_pocket_tools/src/models/qr_scan.dart';
import 'package:nexaara_pocket_tools/src/services/database_service.dart';

void main() {
  late DatabaseService databaseService;
  late Box<QRScan> qrScansBox;

  setUp(() async {
    await Hive.initFlutter();
    Hive.registerAdapter(QRScanAdapter());
    qrScansBox = await Hive.openBox<QRScan>('test_qr_scans');
    databaseService = DatabaseService();
  });

  tearDown(() async {
    await qrScansBox.clear();
    await qrScansBox.close();
  });

  group('DatabaseService QR Scans Tests', () {
    test('should add a QR scan', () async {
      final scan = QRScan(
        id: '1',
        data: 'https://example.com',
        type: 'URL',
        timestamp: DateTime.now(),
      );

      await databaseService.addQRScan(scan);

      final scans = databaseService.getQRScans();
      expect(scans.length, 1);
      expect(scans[0].data, 'https://example.com');
      expect(scans[0].type, 'URL');
    });

    test('should order scans by timestamp descending', () async {
      final scan1 = QRScan(
        id: '1',
        data: 'Data 1',
        type: 'Text',
        timestamp: DateTime.now().subtract(const Duration(hours: 1)),
      );

      final scan2 = QRScan(
        id: '2',
        data: 'Data 2',
        type: 'Text',
        timestamp: DateTime.now(),
      );

      await databaseService.addQRScan(scan1);
      await databaseService.addQRScan(scan2);

      final scans = databaseService.getQRScans();
      expect(scans.length, 2);
      expect(scans[0].id, '2'); // Most recent first
      expect(scans[1].id, '1');
    });

    test('should delete a QR scan', () async {
      final scan = QRScan(
        id: '1',
        data: 'Test Data',
        type: 'Text',
        timestamp: DateTime.now(),
      );

      await databaseService.addQRScan(scan);
      expect(databaseService.getQRScans().length, 1);

      await databaseService.deleteQRScan('1');
      expect(databaseService.getQRScans().length, 0);
    });

    test('should clear all QR scans', () async {
      final scan1 = QRScan(id: '1', data: 'Data 1', type: 'Text', timestamp: DateTime.now());
      final scan2 = QRScan(id: '2', data: 'Data 2', type: 'Text', timestamp: DateTime.now());

      await databaseService.addQRScan(scan1);
      await databaseService.addQRScan(scan2);
      expect(databaseService.getQRScans().length, 2);

      await databaseService.clearAllQRScans();
      expect(databaseService.getQRScans().length, 0);
    });
  });
}
