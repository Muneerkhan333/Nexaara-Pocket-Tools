import 'package:hive/hive.dart';

part 'qr_scan.g.dart';

@HiveType(typeId: 1)
class QRScan extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String data;

  @HiveField(2)
  String type; // 'text', 'url', 'contact', etc.

  @HiveField(3)
  DateTime timestamp;

  QRScan({
    required this.id,
    required this.data,
    required this.type,
    required this.timestamp,
  });
}
