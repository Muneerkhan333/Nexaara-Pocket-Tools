import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/currency.dart';
import '../../services/api_service.dart';
import '../../utils/helpers.dart';

class CurrencyConverterScreen extends StatefulWidget {
  const CurrencyConverterScreen({super.key});

  @override
  State<CurrencyConverterScreen> createState() => _CurrencyConverterScreenState();
}

class _CurrencyConverterScreenState extends State<CurrencyConverterScreen> {
  String _fromCurrency = 'USD';
  String _toCurrency = 'EUR';
  double _amount = 1.0;
  double _convertedAmount = 0.0;
  Map<String, double> _rates = {};
  bool _isLoading = false;

  final TextEditingController _amountController = TextEditingController(text: '1.0');

  @override
  void initState() {
    super.initState();
    _loadRates();
  }

  Future<void> _loadRates() async {
    setState(() => _isLoading = true);
    try {
      _rates = await ApiService.fetchExchangeRates(_fromCurrency);
      _convert();
    } catch (e) {
      Helpers.showSnackBar(context, 'Failed to load rates. Using offline rates.', isError: true);
      _rates = await ApiService._getDefaultRates(_fromCurrency);
      _convert();
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _convert() {
    if (_rates.containsKey(_toCurrency)) {
      setState(() {
        _convertedAmount = _amount * _rates[_toCurrency]!;
      });
    }
  }

  void _swapCurrencies() {
    setState(() {
      final temp = _fromCurrency;
      _fromCurrency = _toCurrency;
      _toCurrency = temp;
      _loadRates();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Currency Converter'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadRates,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Amount Input
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Amount',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _amountController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        hintText: 'Enter amount',
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (value) {
                        _amount = double.tryParse(value) ?? 0.0;
                        _convert();
                      },
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Currency Selection
            Row(
              children: [
                Expanded(
                  child: _CurrencySelector(
                    label: 'From',
                    selectedCurrency: _fromCurrency,
                    onChanged: (currency) {
                      setState(() => _fromCurrency = currency);
                      _loadRates();
                    },
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.swap_horiz, size: 32),
                  onPressed: _swapCurrencies,
                ),
                Expanded(
                  child: _CurrencySelector(
                    label: 'To',
                    selectedCurrency: _toCurrency,
                    onChanged: (currency) {
                      setState(() => _toCurrency = currency);
                      _convert();
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Result
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    if (_isLoading)
                      const CircularProgressIndicator()
                    else ...[
                      Text(
                        '${_amount.toStringAsFixed(2)} $_fromCurrency =',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${_convertedAmount.toStringAsFixed(2)} $_toCurrency',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        '1 $_fromCurrency = ${_rates[_toCurrency]?.toStringAsFixed(4) ?? 'N/A'} $_toCurrency',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Quick Convert Buttons
            const Text(
              'Quick Convert',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [0.1, 1.0, 10.0, 100.0, 1000.0].map((amount) {
                return ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _amount = amount;
                      _amountController.text = amount.toString();
                      _convert();
                    });
                  },
                  child: Text(amount.toString()),
                );
              }).toList(),
            ),

            const SizedBox(height: 24),

            // Favorite Pairs
            const Text(
              'Favorite Pairs',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _FavoritePairCard(
                  from: 'USD',
                  to: 'EUR',
                  onTap: () {
                    setState(() {
                      _fromCurrency = 'USD';
                      _toCurrency = 'EUR';
                      _loadRates();
                    });
                  },
                ),
                _FavoritePairCard(
                  from: 'USD',
                  to: 'PKR',
                  onTap: () {
                    setState(() {
                      _fromCurrency = 'USD';
                      _toCurrency = 'PKR';
                      _loadRates();
                    });
                  },
                ),
                _FavoritePairCard(
                  from: 'EUR',
                  to: 'GBP',
                  onTap: () {
                    setState(() {
                      _fromCurrency = 'EUR';
                      _toCurrency = 'GBP';
                      _loadRates();
                    });
                  },
                ),
                _FavoritePairCard(
                  from: 'GBP',
                  to: 'USD',
                  onTap: () {
                    setState(() {
                      _fromCurrency = 'GBP';
                      _toCurrency = 'USD';
                      _loadRates();
                    });
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }
}

class _CurrencySelector extends StatelessWidget {
  final String label;
  final String selectedCurrency;
  final ValueChanged<String> onChanged;

  const _CurrencySelector({
    required this.label,
    required this.selectedCurrency,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final currency = Currency.currencies.firstWhere(
      (c) => c.code == selectedCurrency,
      orElse: () => Currency.currencies[0],
    );

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () => _showCurrencyPicker(context),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
              ),
              const SizedBox(height: 4),
              Text(
                currency.flag,
                style: const TextStyle(fontSize: 24),
              ),
              const SizedBox(height: 4),
              Text(
                currency.code,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                currency.name,
                style: TextStyle(
                  fontSize: 10,
                  color: Colors.grey[600],
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showCurrencyPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        height: 300,
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text(
              'Select Currency',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: Currency.currencies.length,
                itemBuilder: (context, index) {
                  final currency = Currency.currencies[index];
                  return ListTile(
                    leading: Text(
                      currency.flag,
                      style: const TextStyle(fontSize: 24),
                    ),
                    title: Text(currency.name),
                    subtitle: Text(currency.code),
                    onTap: () {
                      onChanged(currency.code);
                      Navigator.of(context).pop();
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FavoritePairCard extends StatelessWidget {
  final String from;
  final String to;
  final VoidCallback onTap;

  const _FavoritePairCard({
    required this.from,
    required this.to,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final fromCurrency = Currency.currencies.firstWhere((c) => c.code == from);
    final toCurrency = Currency.currencies.firstWhere((c) => c.code == to);

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(fromCurrency.flag, style: const TextStyle(fontSize: 16)),
                  const SizedBox(width: 4),
                  Text(from, style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(width: 8),
                  const Icon(Icons.arrow_forward, size: 16),
                  const SizedBox(width: 8),
                  Text(toCurrency.flag, style: const TextStyle(fontSize: 16)),
                  const SizedBox(width: 4),
                  Text(to, style: const TextStyle(fontWeight: FontWeight.w600)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
