import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdsService extends ChangeNotifier {
  static const String bannerAdUnitId = 'ca-app-pub-3940256099942544/6300978111'; // Test ID
  static const String interstitialAdUnitId = 'ca-app-pub-3940256099942544/1033173712'; // Test ID

  BannerAd? _bannerAd;
  InterstitialAd? _interstitialAd;

  bool _isPremium = false; // Mock premium status

  bool get isPremium => _isPremium;

  static Future<void> init() async {
    await MobileAds.instance.initialize();
  }

  BannerAd? get bannerAd => _isPremium ? null : _bannerAd;

  void loadBannerAd() {
    if (_isPremium) return;

    _bannerAd = BannerAd(
      adUnitId: bannerAdUnitId,
      request: const AdRequest(),
      size: AdSize.banner,
      listener: BannerAdListener(
        onAdLoaded: (ad) => notifyListeners(),
        onAdFailedToLoad: (ad, err) {
          ad.dispose();
          _bannerAd = null;
          notifyListeners();
        },
      ),
    )..load();
  }

  void loadInterstitialAd() {
    if (_isPremium) return;

    InterstitialAd.load(
      adUnitId: interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
        },
        onAdFailedToLoad: (error) {
          _interstitialAd = null;
        },
      ),
    );
  }

  void showInterstitialAd() {
    if (_interstitialAd != null && !_isPremium) {
      _interstitialAd!.show();
      _interstitialAd = null;
      loadInterstitialAd(); // Load next one
    }
  }

  void upgradeToPremium() {
    _isPremium = true;
    _bannerAd?.dispose();
    _bannerAd = null;
    notifyListeners();
  }

  void dispose() {
    _bannerAd?.dispose();
    _interstitialAd?.dispose();
  }
}
