# TODO List for Nexaara Pocket Tools Flutter App

## Project Setup
- [ ] Create directory structure (lib/src/ui/screens, widgets, themes, models, services, utils, assets/fonts, images, lottie, test)
- [ ] Create pubspec.yaml with all dependencies
- [ ] Run flutter pub get

## Core Files
- [ ] Create main.dart (app entry point, themes, navigation)
- [ ] Create lib/src/models/note.dart
- [ ] Create lib/src/models/qr_scan.dart
- [ ] Create lib/src/models/currency.dart
- [ ] Create lib/src/services/database_service.dart (Hive or sqflite)
- [ ] Create lib/src/services/api_service.dart (for currency rates)
- [ ] Create lib/src/services/ads_service.dart (AdMob placeholders)
- [ ] Create lib/src/services/google_sheets_service.dart (Apps Script)
- [ ] Create lib/src/utils/constants.dart
- [ ] Create lib/src/utils/helpers.dart
- [ ] Create lib/src/ui/themes/app_theme.dart

## Screens
- [ ] Create lib/src/ui/screens/home_screen.dart
- [ ] Create lib/src/ui/screens/qr_scanner_screen.dart
- [ ] Create lib/src/ui/screens/notes_screen.dart
- [ ] Create lib/src/ui/screens/currency_converter_screen.dart
- [ ] Create lib/src/ui/screens/settings_screen.dart
- [ ] Create lib/src/ui/screens/onboarding_screen.dart

## Widgets
- [ ] Create lib/src/ui/widgets/custom_button.dart
- [ ] Create lib/src/ui/widgets/glassmorphism_card.dart
- [ ] Create lib/src/ui/widgets/shimmer_loader.dart
- [ ] Create lib/src/ui/widgets/multi_action_fab.dart

## Assets and Docs
- [ ] Create assets folders (fonts, images, lottie) - placeholders
- [ ] Create README.md
- [ ] Create privacy_policy.md
- [ ] Create apps-script.gs

## Testing
- [ ] Create test/note_service_test.dart
- [ ] Create test/qr_service_test.dart

## Final Steps
- [ ] Test the app with flutter run
- [ ] Ensure all features work offline
- [ ] Verify UI/UX matches design specs
