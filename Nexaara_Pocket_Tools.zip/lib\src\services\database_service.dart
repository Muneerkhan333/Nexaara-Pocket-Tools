import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';
import '../models/note.dart';
import '../models/qr_scan.dart';

class DatabaseService extends ChangeNotifier {
  late Box<Note> _notesBox;
  late Box<QRScan> _qrScansBox;

  DatabaseService() {
    _initBoxes();
  }

  Future<void> _initBoxes() async {
    _notesBox = Hive.box<Note>('notes');
    _qrScansBox = Hive.box<QRScan>('qr_scans');
  }

  // Notes CRUD
  List<Note> getNotes() {
    return _notesBox.values.toList()
      ..sort((a, b) {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        return b.updatedAt.compareTo(a.updatedAt);
      });
  }

  Future<void> addNote(Note note) async {
    await _notesBox.put(note.id, note);
    notifyListeners();
  }

  Future<void> updateNote(Note note) async {
    note.updatedAt = DateTime.now();
    await _notesBox.put(note.id, note);
    notifyListeners();
  }

  Future<void> deleteNote(String id) async {
    await _notesBox.delete(id);
    notifyListeners();
  }

  // QR Scans
  List<QRScan> getQRScans() {
    return _qrScansBox.values.toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  Future<void> addQRScan(QRScan scan) async {
    await _qrScansBox.put(scan.id, scan);
    notifyListeners();
  }

  Future<void> deleteQRScan(String id) async {
    await _qrScansBox.delete(id);
    notifyListeners();
  }

  Future<void> clearAllQRScans() async {
    await _qrScansBox.clear();
    notifyListeners();
  }
}
