import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/currency.dart';

class ApiService {
  static const String _baseUrl = 'https://api.exchangerate-api.com/v4/latest/';

  // Fetch real-time exchange rates
  static Future<Map<String, double>> fetchExchangeRates(String baseCurrency) async {
    try {
      final response = await http.get(Uri.parse('$_baseUrl$baseCurrency'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final rates = data['rates'] as Map<String, dynamic>;
        return rates.map((key, value) => MapEntry(key, value.toDouble()));
      } else {
        throw Exception('Failed to load exchange rates');
      }
    } catch (e) {
      // Return default rates if API fails
      return _getDefaultRates(baseCurrency);
    }
  }

  // Default offline rates
  static Map<String, double> _getDefaultRates(String base) {
    // Simplified rates - in real app, store more comprehensive offline data
    const rates = {
      'USD': {'EUR': 0.85, 'GBP': 0.73, 'PKR': 280.0, 'INR': 83.0},
      'EUR': {'USD': 1.18, 'GBP': 0.86, 'PKR': 330.0, 'INR': 98.0},
      'GBP': {'USD': 1.37, 'EUR': 1.16, 'PKR': 385.0, 'INR': 114.0},
      'PKR': {'USD': 0.0036, 'EUR': 0.0030, 'GBP': 0.0026, 'INR': 0.30},
      'INR': {'USD': 0.012, 'EUR': 0.010, 'GBP': 0.0088, 'PKR': 3.33},
    };

    return rates[base] ?? {'USD': 1.0};
  }
}
