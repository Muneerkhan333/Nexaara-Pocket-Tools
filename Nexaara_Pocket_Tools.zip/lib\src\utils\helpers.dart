import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:csv/csv.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/note.dart';
import '../models/qr_scan.dart';

class Helpers {
  // Generate unique ID
  static String generateId() {
    return DateTime.now().millisecondsSinceEpoch.toString();
  }

  // Format date
  static String formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
  }

  // Export notes to CSV
  static Future<void> exportNotesToCSV(List<Note> notes) async {
    List<List<String>> csvData = [
      ['ID', 'Title', 'Content', 'Created At', 'Updated At', 'Color', 'Pinned']
    ];

    for (var note in notes) {
      csvData.add([
        note.id,
        note.title,
        note.content,
        note.createdAt.toIso8601String(),
        note.updatedAt.toIso8601String(),
        note.colorIndex.toString(),
        note.isPinned.toString(),
      ]);
    }

    String csv = const ListToCsvConverter().convert(csvData);
    await _saveAndShareFile(csv, 'notes.csv', 'text/csv');
  }

  // Export QR scans to CSV
  static Future<void> exportQRScansToCSV(List<QRScan> scans) async {
    List<List<String>> csvData = [
      ['ID', 'Data', 'Type', 'Timestamp']
    ];

    for (var scan in scans) {
      csvData.add([
        scan.id,
        scan.data,
        scan.type,
        scan.timestamp.toIso8601String(),
      ]);
    }

    String csv = const ListToCsvConverter().convert(csvData);
    await _saveAndShareFile(csv, 'qr_scans.csv', 'text/csv');
  }

  // Save and share file
  static Future<void> _saveAndShareFile(String content, String fileName, String mimeType) async {
    final directory = await getTemporaryDirectory();
    final file = File('${directory.path}/$fileName');
    await file.writeAsString(content);
    await Share.shareXFiles([XFile(file.path)], text: 'Exported from Nexaara Pocket Tools');
  }

  // Launch URL
  static Future<void> launchURL(String url) async {
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    }
  }

  // Launch email
  static Future<void> launchEmail(String email) async {
    final Uri emailUri = Uri(
      scheme: 'mailto',
      path: email,
      queryParameters: {'subject': 'Support Request - Nexaara Pocket Tools'},
    );
    if (await canLaunchUrl(emailUri)) {
      await launchUrl(emailUri);
    }
  }

  // Show snackbar
  static void showSnackBar(BuildContext context, String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // Validate email
  static bool isValidEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  // Capitalize first letter
  static String capitalize(String text) {
    if (text.isEmpty) return text;
    return text[0].toUpperCase() + text.substring(1);
  }
}
