class AppConstants {
  // App Info
  static const String appName = 'Nexaara Pocket Tools';
  static const String appVersion = '1.0.0';
  static const String appSlogan = 'Your Pocket Powerhouse';

  // Colors
  static const int primaryColor = 0xFF23395B; // Deep Indigo
  static const int accentColor = 0xFF0FB9B1; // Electric Cyan
  static const int highlightColor = 0xFFF7C948; // Soft Gold
  static const int backgroundColor = 0xFFF6F7FB; // Light Gray
  static const int darkBackgroundColor = 0xFF1A1A1A;

  // URLs
  static const String privacyPolicyUrl = 'https://yourapp.com/privacy';
  static const String supportEmail = 'support@nexaara.com';

  // AdMob Test IDs (replace with real ones)
  static const String bannerAdUnitId = 'ca-app-pub-3940256099942544/6300978111';
  static const String interstitialAdUnitId = 'ca-app-pub-3940256099942544/1033173712';

  // Google Sheets
  static const String googleSheetsScriptUrl = 'https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec';
  static const String googleSheetsToken = 'your_secret_token_here';

  // Animation durations
  static const Duration shortAnimation = Duration(milliseconds: 200);
  static const Duration mediumAnimation = Duration(milliseconds: 500);
  static const Duration longAnimation = Duration(milliseconds: 1000);
}
