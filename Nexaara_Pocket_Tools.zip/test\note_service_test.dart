import 'package:flutter_test/flutter_test.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:nexaara_pocket_tools/src/models/note.dart';
import 'package:nexaara_pocket_tools/src/services/database_service.dart';

void main() {
  late DatabaseService databaseService;
  late Box<Note> notesBox;

  setUp(() async {
    await Hive.initFlutter();
    Hive.registerAdapter(NoteAdapter());
    notesBox = await Hive.openBox<Note>('test_notes');
    databaseService = DatabaseService();
  });

  tearDown(() async {
    await notesBox.clear();
    await notesBox.close();
  });

  group('DatabaseService Notes Tests', () {
    test('should add a note', () async {
      final note = Note(
        id: '1',
        title: 'Test Note',
        content: 'Test Content',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await databaseService.addNote(note);

      final notes = databaseService.getNotes();
      expect(notes.length, 1);
      expect(notes[0].title, 'Test Note');
    });

    test('should update a note', () async {
      final note = Note(
        id: '1',
        title: 'Test Note',
        content: 'Test Content',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await databaseService.addNote(note);

      final updatedNote = Note(
        id: '1',
        title: 'Updated Note',
        content: 'Updated Content',
        createdAt: note.createdAt,
        updatedAt: DateTime.now(),
      );

      await databaseService.updateNote(updatedNote);

      final notes = databaseService.getNotes();
      expect(notes[0].title, 'Updated Note');
      expect(notes[0].content, 'Updated Content');
    });

    test('should delete a note', () async {
      final note = Note(
        id: '1',
        title: 'Test Note',
        content: 'Test Content',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await databaseService.addNote(note);
      expect(databaseService.getNotes().length, 1);

      await databaseService.deleteNote('1');
      expect(databaseService.getNotes().length, 0);
    });

    test('should pin notes to top', () async {
      final pinnedNote = Note(
        id: '1',
        title: 'Pinned Note',
        content: 'Content',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
        isPinned: true,
      );

      final regularNote = Note(
        id: '2',
        title: 'Regular Note',
        content: 'Content',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
        isPinned: false,
      );

      await databaseService.addNote(regularNote);
      await databaseService.addNote(pinnedNote);

      final notes = databaseService.getNotes();
      expect(notes[0].isPinned, true);
      expect(notes[1].isPinned, false);
    });
  });
}
